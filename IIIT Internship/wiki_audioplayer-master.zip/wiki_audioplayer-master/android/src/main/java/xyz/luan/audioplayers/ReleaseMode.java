package xyz.luan.audioplayers;

public enum ReleaseMode {
    RELEASE, LOOP, STOP
}
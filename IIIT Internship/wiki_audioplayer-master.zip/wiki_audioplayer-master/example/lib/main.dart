import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
//import 'package:simple_permissions/simple_permissions.dart';
import 'package:path_provider/path_provider.dart';
import 'player_widget.dart';

typedef void OnError(Exception exception);

const kUrl1 = 'https://luan.xyz/files/audio/ambient_c_motion.mp3';
const kUrl2 = 'https://luan.xyz/files/audio/nasa_on_a_mission.mp3';
const kUrl3 = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio1xtra_mf_p';

void main() {
  runApp(new MaterialApp(home: new ExampleApp()));
}

class ExampleApp extends StatefulWidget {
  @override
  _ExampleAppState createState() => new _ExampleAppState();
}

class _ExampleAppState extends State<ExampleApp> {
  AudioCache audioCache = new AudioCache();
  AudioPlayer advancedPlayer = new AudioPlayer();
  String localFilePath;
  String oldtxt=""; //Old entered text in textfield
  String newtxt=""; //New entered text in textfield
  var count = 0; //count for the prev and next buttons
  var time; //time stamp
  var maxlen=0;
  String data=""; //Adding the keylogger content to a variable 'data'
  var usernameController;
  static var EnglishVersion = ["A tradition is a belief or behavior passed down within a group or society with symbolic meaning or special significance with origins in the past.","Common examples include holidays or impractical but socially meaningful clothes (like lawyers' wigs or military officers' spurs), but the idea has also been applied to social norms such as greetings.","Traditions can persist and evolve for thousands of years—the word tradition itself derives from the Latin tradere literally meaning to transmit, to hand over, to give for safekeeping.","While it is commonly assumed that traditions have ancient history, many traditions have been invented on purpose, whether that be political or cultural, over short periods of time.","Various academic disciplines also use the word in a variety of ways.","Traditions can persist and evolve for thousands of years—the word tradition itself derives from the Latin tradere literally meaning to transmit, to hand over, to give for safekeeping. While it is commonly assumed that traditions have ancient history, many traditions have been invented on purpose, whether that be political or cultural, over short periods of time. Various academic disciplines also use the word in a variety of ways."];
  String Engtxt= EnglishVersion[0];
  String charc="";


  Widget _tab(List<Widget> children) {
    return Center(
      child: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: children
              .map((w) => Container(child: w, padding: EdgeInsets.all(6.0)))
              .toList(),
        ),
      ),
    );
  }

  Widget remoteUrl() {
    return SingleChildScrollView(
      child: _tab([
        Text(
          'Sample 1 ($kUrl1)',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        PlayerWidget(url: kUrl1),
        new Card(
          child: ListTile (
            leading: new TextField(
              onChanged: (text){
                charc = text;
                newtxt=text; //new text
                time = new DateTime.now().millisecondsSinceEpoch;
                if(oldtxt.length<newtxt.length){
                  for(int i=0;i<newtxt.length;i++){
                    var diff1= (newtxt.length-oldtxt.length).abs();
                    if(i==oldtxt.length){
                      for(int k=i;k<i+diff1;k++){
                        if(newtxt[k]==" "){
                          data += "INSERT|SP"+"|$time"+"|$charc"+"\n";
                          print(data);
                        }
                        else {
                          data +="INSERT|" + newtxt[k] + "|$time" +"|$charc"+"\n";
                          print(data);
                        }
                      }
                      break;
                    }
                    if(newtxt[i]!=oldtxt[i]){
                      for(int k=i;k<i+diff1;k++){
                        if(newtxt[k]==" "){
                          data += "INSERT|SP"+"|$time"+"$charc"+"\n";
                          print(data);
                        }
                        else {
                          data +="INSERT|" + newtxt[k] + "|$time" +"|$charc"+ "\n";
                          print("INSERT|" + newtxt[k] + "|$time"+"|$charc");
                        }
                      }
                      break;
                    }
                  }
                }

                else if(newtxt.length<oldtxt.length){
                  var flag =0;
                  var diff= (newtxt.length-oldtxt.length).abs();
                  for(int i=0;i<newtxt.length;i++){
                    if(oldtxt[i]==newtxt[i]){
                      continue;
                    }
                    else{
                      if(oldtxt[i]==" "){
                        data += "DELETE|SP"+"|$time"+"|$charc"+"\n";
                        print(data);
                      }
                      else{
                        data+="DELETE|"+oldtxt[oldtxt.length-1]+"|$time"+"|$charc"+"\n";
                        print(data);
                      }
                      flag = 1;
                      break;
                    }
                  }
                  if(flag == 0){
                    if(oldtxt[oldtxt.length-1]==" "){
                      data+="DELETE|SP"+"$time"+"|$charc"+"\n";
                    }
                    else{
                      data+="DELETE|"+oldtxt[oldtxt.length-1]+"|$time"+"|$charc"+"\n";
                      print(data);
                    }
                  }
                }
//                this._writeToFile(data);
                oldtxt=newtxt; //old text
              },
              keyboardType: TextInputType.multiline,
              maxLines: null,
              autofocus: true,
              decoration: new InputDecoration.collapsed(
                  hintText: 'Start tying here...'
              ),
              style: new TextStyle(fontSize: 14.0),
            ),
          ),
        ),
      ]),
    );
  }

//  bool _allowWriteFile = false;
//
//  @override
//  void initState() {
//    super.initState();
//    requestWritePermission();
//  }
//
//  // Platform messages are asynchronous, so we initialize in an async method.
//  requestWritePermission() async {
//    PermissionStatus permissionStatus = await SimplePermissions.requestPermission(Permission.WriteExternalStorage);
//
//    if (permissionStatus == PermissionStatus.authorized) {
//      setState(() {
//        _allowWriteFile = true;
//      });
//    }
//  }
//
//  Future get _localPath async {
//    // Application documents directory: /data/user/0/{package_name}/{app_name}
//    final applicationDirectory = await getApplicationDocumentsDirectory();
//
//    // External storage directory: /storage/emulated/0
//    final externalDirectory = await getExternalStorageDirectory();
//
//    // Application temporary directory: /data/user/0/{package_name}/cache
//    final tempDirectory = await getTemporaryDirectory();
//    print(externalDirectory);
//    return externalDirectory.path;
//  }
//
//  Future get _localFile async {
//    final path = await _localPath;
//    print(path);
//    return File('$path/MyLogData.txt');
//  }
//
//
//  Future _writeToFile(String text) async {
//    try{
//      if (!_allowWriteFile) {
//        return null;
//      }
//
//      final file = await _localFile;
//
//      // Write the file
//      File result = await file.writeAsString('$text');
//      if (result == null ) {
//        print("Writing to file failed");
//      } else {
//        print("Successfully writing to file");
//
//        print("Reading the content of file");
//        String readResult = await _readFile();
//        print("readResult: " + readResult.toString());
//      }
//    }
//    catch(e){
//      return null;
//    }
//
//  }
//
//
//
//  Future _readFile() async {
//    try {
//      final file = await _localFile;
//
//      // Read the file
//      return await file.readAsString();
//    } catch (e) {
//      // Return null if we encounter an error
//      return null;
//    }
//  }


  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
            leading: IconButton(icon: new Icon(Icons.arrow_back_ios),
              onPressed: (){
                setState(() {
                  if(count >0){
                    count = count-1;
                    Engtxt = EnglishVersion[count];
                  }
                });
              },
              color: Colors.black,
            ),
            actions: [
              new IconButton(icon: new Icon(Icons.arrow_forward_ios),
                onPressed: (){
                  setState(() {
                    if(count < EnglishVersion.length-1){
                      count = count +1;
                      Engtxt = EnglishVersion[count];
                    }
                  });
                },
                color: Colors.black,
              ),
            ],
          title: Text('Audio Translation'),
        ),
        body: TabBarView(
          children: [
            remoteUrl()
          ],
        ),
      ),
    );
  }
}

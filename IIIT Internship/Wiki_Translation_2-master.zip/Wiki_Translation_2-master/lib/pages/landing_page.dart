//Import required packages

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
//import './files_utils.dart';
import './Keyboard_Scroll.dart';
import 'package:path_provider/path_provider.dart';
import 'package:simple_permissions/simple_permissions.dart';
import 'dart:async';
import 'dart:io';

//Class is of stateful widget

class LandingPage extends StatefulWidget{
  @override
  LandingPageState createState() => new LandingPageState();
}


class LandingPageState extends State<LandingPage>{

//  Initialise and declare variables

  bool i =true;
  String data=""; //Adding the keylogger content to a variable 'data'
  var newline = '\n';
  String oldtxt=""; //Old entered text in textfield
  String newtxt=""; //New entered text in textfield
  var tag = "Google"; // Tag if the telugu version is google or microsoft
  var usernameController;
  var count = 0; //count for the prev and next buttons
  var time; //time stamp
  var maxlen=0;
  static var MicrosoftVersion=["ఒక సంప్రదాయం అనేది ఒక సమూహం లేదా సమాజం లోపల ఒక నమ్మకం లేదా ఒక ప్రవర్తన ఒక సింబాలిక్ అర్థం లేదా గతంలో మూలాలు తో ప్రత్యేక ప్రాముఖ్యత తో ఆమోదించింది.","సాధారణ ఉదాహరణలు సెలవులు లేదా ఆచరణాత్మకంగా కానీ సామాజికంగా అర్ధవంతమైన దుస్తులను (లాయర్ల యొక్క wigs లేదా మిలిటరీ ఆఫీసర్ల ' లూ వంటివి) కలిగి ఉంటాయి, అయితే ఈ ఆలోచన శుభాకాంక్షలు వంటి సామాజిక ప్రమాణాలలో కూడా అన్వయించబడింది.","సంప్రదాయాలు కొన్ని వేల సంవత్సరాలపాటు కొనసాగవచ్చు, పరిణామం చెందుతాయి-సంప్రదాయం అనే పదం లాటిన్ దినదిరే వాచకం నుండి ప్రసారం చేయడానికి, చేతితో ఉంచడానికి, భద్రత కోసం ఇవ్వడానికి అని అర్థం.","సాంప్రదాయాలకు పురాతన చరిత్ర ఉందని సాధారణంగా భావించబడుతోంది, అయితే రాజకీయ లేదా సాంస్కృతిక, స్వల్పకాల వ్యవధిలో అనేక సంప్రదాయాలు ప్రయోజనం కోసం కనిపెట్టాయి.","వివిధ విద్యా విభాగాలు కూడా ఈ పదాన్ని పలు విధాలుగా ఉపయోగిస్తాయి.","సంప్రదాయాలు కొన్ని వేల సంవత్సరాలపాటు కొనసాగవచ్చు, పరిణామం చెందుతాయి-సంప్రదాయం అనే పదం లాటిన్ దినదినా వాచకం నుండి, ప్రసారం చేయడానికి, చేతితో ఉంచడానికి, రక్షించడానికి ఇవ్వడమని అర్థం. సాంప్రదాయాలకు ప్రాచీన చరిత్ర ఉందని సాధారణంగా భావించాల్సి ఉండగా, అనేక సంప్రదాయాలు, రాజకీయ లేదా సాంస్కృతిక, స్వల్పకాల వ్యవధిలో ఒక ప్రయోజనం కోసం కనిపెట్టాయి. వివిధ విద్యా విభాగాలు కూడా ఈ పదాన్ని పలు విధాలుగా ఉపయోగిస్తాయి."];
  static var EnglishVersion = ["A tradition is a belief or behavior passed down within a group or society with symbolic meaning or special significance with origins in the past.","Common examples include holidays or impractical but socially meaningful clothes (like lawyers' wigs or military officers' spurs), but the idea has also been applied to social norms such as greetings.","Traditions can persist and evolve for thousands of years—the word tradition itself derives from the Latin tradere literally meaning to transmit, to hand over, to give for safekeeping.","While it is commonly assumed that traditions have ancient history, many traditions have been invented on purpose, whether that be political or cultural, over short periods of time.","Various academic disciplines also use the word in a variety of ways.","Traditions can persist and evolve for thousands of years—the word tradition itself derives from the Latin tradere literally meaning to transmit, to hand over, to give for safekeeping. While it is commonly assumed that traditions have ancient history, many traditions have been invented on purpose, whether that be political or cultural, over short periods of time. Various academic disciplines also use the word in a variety of ways."];
  static var GoogleVersion = ["ఒక సంప్రదాయం అనేది గతంలోని మూలాలతో సంకేత అర్ధంతో లేదా ప్రత్యేక ప్రాముఖ్యతతో గుంపులో లేదా సమాజంలోకి వెళ్ళిన నమ్మకం లేదా ప్రవర్తన.","సాధారణ ఉదాహరణలలో సెలవులు లేదా అసాధ్యమైనవి కానీ సామాజిక అర్ధవంతమైన బట్టలు (న్యాయవాదుల లు లేదా సైనిక అధికారుల స్పర్స్ వంటివి), కానీ ఈ ఆలోచన కూడా గ్రీటింగ్లు వంటి సాంఘిక ప్రమాణాలకు","సాంప్రదాయాలను వేల సంవత్సరాలపాటు కొనసాగించి, పరిణామం చేయవచ్చు-లాటిన్ పదము నుండి వచ్చిన సంప్రదాయం అనే పదం వాచ్యంగా బదిలీ చేయడానికి, స్వాధీనం చేసుకునేందుకు, భద్రపరచడానికి","సాంప్రదాయాలకు పురాతన చరిత్ర ఉందని సాధారణంగా భావించబడుతున్నప్పటికీ, అనేక సంప్రదాయాలు ప్రయోజనం కోసం కనిపెట్టబడ్డాయి, ఇది రాజకీయ లేదా సాంస్కృతిక, స్వల్ప కాల వ్యవధిలో","వివిధ విద్యా విభాగాలు ఈ పదాన్ని విభిన్న మార్గాల్లో కూడా ఉపయోగిస్తాయి.","సాంప్రదాయాలు వేలాది సంవత్సరాల పాటు కొనసాగుతాయి మరియు పరిణామం చెందగలవు - సంప్రదాయం అనే పదం లాటిన్ సంప్రదాయాల నుండి వాడబడుతుంది, దీని అర్థం వాచ్యంగా బదిలీ చేయడానికి, స్వాధీనం చేసుకోవడానికి, భద్రత కోసం ఇవ్వడానికి. సాంప్రదాయాలకు పురాతన చరిత్ర ఉందని సాధారణంగా భావించబడుతుంది, అయితే అనేక సంప్రదాయాలు ప్రయోజనం కోసం కనిపెట్టబడ్డాయి, ఇది స్వల్ప కాల వ్యవధిలో రాజకీయ లేదా సాంస్కృతికంగా ఉంటుంది. వివిధ విద్యా విభాగాలు ఈ పదాన్ని విభిన్న మార్గాల్లో కూడా ఉపయోగిస్తాయి."];
  String Engtxt= EnglishVersion[0];
  String Googletxt = GoogleVersion[0];
  FocusNode _focusNode = new FocusNode();

  bool _allowWriteFile = false;

  @override
  void initState() {
    super.initState();
    requestWritePermission();
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  requestWritePermission() async {
    PermissionStatus permissionStatus = await SimplePermissions.requestPermission(Permission.WriteExternalStorage);

    if (permissionStatus == PermissionStatus.authorized) {
      setState(() {
        _allowWriteFile = true;
      });
    }
  }

  Future get _localPath async {
    // Application documents directory: /data/user/0/{package_name}/{app_name}
    final applicationDirectory = await getApplicationDocumentsDirectory();

    // External storage directory: /storage/emulated/0
    final externalDirectory = await getExternalStorageDirectory();

    // Application temporary directory: /data/user/0/{package_name}/cache
    final tempDirectory = await getTemporaryDirectory();
    print(externalDirectory);
    return externalDirectory.path;
  }

  Future get _localFile async {
    final path = await _localPath;
    print(path);
    return File('$path/MyLogData.txt');
  }


  Future _writeToFile(String text) async {
    if (!_allowWriteFile) {
      return null;
    }

    final file = await _localFile;

    // Write the file
    File result = await file.writeAsString('$text');
    if (result == null ) {
      print("Writing to file failed");
    } else {
      print("Successfully writing to file");

      print("Reading the content of file");
      String readResult = await _readFile();
      print("readResult: " + readResult.toString());
    }
  }



  Future _readFile() async {
    try {
      final file = await _localFile;

      // Read the file
      return await file.readAsString();
    } catch (e) {
      // Return null if we encounter an error
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
          title: new Text("Edit Translation"), //Title for the page
          leading: IconButton(icon: new Icon(Icons.arrow_back_ios),
            onPressed: (){
              setState(() {
                if(count >0){
                  count = count-1;
                  Engtxt = EnglishVersion[count];
                  Googletxt = GoogleVersion[count];
                }
//                count = count >0 ? count-1 : count;

              });
            },
            color: Colors.black,),
          actions: [
            new IconButton(icon: new Icon(Icons.arrow_forward_ios),
              onPressed: (){
                setState(() {
                  if(count < EnglishVersion.length-1){
                    count = count +1;
                    Engtxt = EnglishVersion[count];
                    Googletxt = GoogleVersion[count];
                  }
//                  count = count < EnglishVersion.length ? count+1 : count;
//                  Engtxt = EnglishVersion[count];
//                  Googletxt = GoogleVersion[count];

                });
              },
              color: Colors.black,
            ),
          ]
      ),
      body: new SafeArea(
        top: false,
        bottom: false,
        child: new SingleChildScrollView(
          child: new Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              new Material(
                child: new Center(
                  child: new Column(
                    children: <Widget>[
                      //card of english text
                      //card of english text
                      new Card(
                        child: ListTile(
                          title:  new Text(Engtxt),
                        ),
                      ),
                      //card of telugu text display
                      new Card(
                        child: ListTile(
                          title: new Text(Googletxt,style: new TextStyle(fontSize: 14.0),),
                          subtitle: new Text(tag,style: TextStyle(color:Colors.lightBlue[800]),),
                          isThreeLine: true,
                          trailing: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                IconButton(icon: new Icon(Icons.g_translate),iconSize: 15.0,
                                    padding: const EdgeInsets.only(bottom: 30.0),
                                    onPressed: () {
                                      setState(() {
                                        if(i== true){
                                          i=false;
                                        }
                                        else{ i= true;}
                                        print(i);

                                        if(i==true){Googletxt=GoogleVersion[count];tag = "Google";}
                                        else{Googletxt= MicrosoftVersion[count];tag="Micosoft";}
                                      });
                                    },
                                    color: Colors.black
                                ),
                                IconButton(icon: new Icon(Icons.edit),iconSize: 20.0,
                                    padding: const EdgeInsets.only( bottom: 20.0),
                                    onPressed: (){
                                      setState(() {
                                        usernameController = TextEditingController(text: Googletxt);
                                      });
                                    },
                                    color: Colors.black
                                ),
                              ]
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              //Card of the textfield
              new Card(
                child: ListTile (
                  title: new EnsureVisibleWhenFocused(
                    focusNode: _focusNode,
                    child: new TextField(
                      onChanged: (text){
                        newtxt=text; //new text
                        time = new DateTime.now().millisecondsSinceEpoch; //store timestamp in time string
                        //check if the new text length is more than old text i.e., Text is Added
                        if(oldtxt.length<newtxt.length){
                          for(int i=0;i<newtxt.length;i++){
                            var diff1= (newtxt.length-oldtxt.length).abs();
                            if(i==oldtxt.length){
                              for(int k=i;k<i+diff1;k++){
                                data += "added: "+newtxt[k]+" at time: $time"+"\n";
                                print("added: "+newtxt[k]+" at time: $time");
                              }
                              break;
                            }
                            if(newtxt[i]!=oldtxt[i]){
                              for(int k=i;k<i+diff1;k++){
                                data += "added: "+newtxt[k]+" at time: $time"+"\n";
                                print("added: "+newtxt[k]+" at time: $time");
                              }
                              break;
                            }
                          }
                        }
                        //check if the new text length is less than old text i.e., Text is deleted
                        else if(newtxt.length<oldtxt.length){
                          var flag =0;
                          var diff= (newtxt.length-oldtxt.length).abs();
                          for(int i=0;i<newtxt.length;i++){
                            if(oldtxt[i]==newtxt[i]){
                              continue;
                            }
                            else{
                              data+="Deleted: "+oldtxt[oldtxt.length-1]+" at time: $time"+"\n";
                              print("Deleted: "+oldtxt[i]+" at time: $time");
                              flag = 1;
                              break;
                            }

                          }
                          if(flag == 0){
                            data+="Deleted: "+oldtxt[oldtxt.length-1]+" at time: $time"+"\n";
                            print("Deleted: "+oldtxt[oldtxt.length-1]+" at time: $time");
                          }
                        }
                        this._writeToFile(data);
                        oldtxt=newtxt; //old text
                      },
                      keyboardType: TextInputType.multiline,
                      maxLines: null,
                      autofocus: true,
                      controller: usernameController,
                      decoration: new InputDecoration.collapsed(
                          hintText: 'Start Typing here..'
                      ),
                      style: new TextStyle(fontSize: 14.0),
                      focusNode: _focusNode,
                    ),
                  ),
                  //Done button
                  trailing: IconButton(icon:new Icon(Icons.done),iconSize: 20.0,
                    onPressed: (){
                      setState(() {
                        usernameController.clear();
                        //Showing toast message
                        Fluttertoast.showToast(msg:"Submitted",
                          toastLength: Toast.LENGTH_SHORT,
                          timeInSecForIos: 1,
                          gravity: ToastGravity.BOTTOM,
                        );
                        count = count < EnglishVersion.length ? count+1 : count;
                        Engtxt = EnglishVersion[count];
                        Googletxt = GoogleVersion[count];

                      });
                    },
                    color:Colors.green,),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
//import 'package:flutter_demo/edit.dart';


class newUI extends StatefulWidget{

  @override
  newUIState createState() => new newUIState();

}

class newUIState extends State<newUI>{

  int _page=0;

//  final PageProducts _listProducts = PageProducts();
  static var EnglishVersion = ["A tradition is a belief or behavior passed down within a group or society with symbolic meaning or special significance with origins in the past.","Common examples include holidays or impractical but socially meaningful clothes (like lawyers' wigs or military officers' spurs), but the idea has also been applied to social norms such as greetings"," Traditions can persist and evolve for thousands of years—the word tradition itself derives from the Latin tradere literally meaning to transmit, to hand over, to give for safekeeping.","While it is commonly assumed that traditions have ancient history, many traditions have been invented on purpose, whether that be political or cultural, over short periods of time.","Various academic disciplines also use the word in a variety of ways."];
  static var GoogleVersion = ["ఒక సంప్రదాయం అనేది ఒక సమూహం లేదా సమాజం లోపల ఒక నమ్మకం లేదా ఒక ప్రవర్తన ఒక సింబాలిక్ అర్థం లేదా గతంలో మూలాలు తో ప్రత్యేక ప్రాముఖ్యత తో ఆమోదించింది.","సాధారణ ఉదాహరణలలో సెలవులు లేదా అసాధ్యమైనవి కానీ సామాజిక అర్ధవంతమైన బట్టలు (న్యాయవాదుల లు లేదా సైనిక అధికారుల స్పర్స్ వంటివి), కానీ ఈ ఆలోచన కూడా గ్రీటింగ్లు వంటి సాంఘిక ప్రమాణాలకు.","సాంప్రదాయాలను వేల సంవత్సరాలపాటు కొనసాగించి, పరిణామం చేయవచ్చు-లాటిన్ పదము నుండి వచ్చిన సంప్రదాయం అనే పదం వాచ్యంగా బదిలీ చేయడానికి, స్వాధీనం చేసుకునేందుకు, భద్రపరచడానికి","సాంప్రదాయాలకు పురాతన చరిత్ర ఉందని సాధారణంగా భావించబడుతున్నప్పటికీ, అనేక సంప్రదాయాలు ప్రయోజనం కోసం కనిపెట్టబడ్డాయి, ఇది రాజకీయ లేదా సాంస్కృతిక, స్వల్ప కాల వ్యవధిలో","వివిధ విద్యా విభాగాలు ఈ పదాన్ని విభిన్న మార్గాల్లో కూడా ఉపయోగిస్తాయి"];
  var count = 0;
  @override
  Widget build(BuildContext context) {

    return Scaffold(
        resizeToAvoidBottomPadding: false,
        bottomNavigationBar: CurvedNavigationBar(
            index: 0,
            items:<Widget>[
              Icon(Icons.first_page,size: 25,),
              Icon(Icons.keyboard_arrow_left,size: 25,),
              Icon(Icons.add_circle_outline,size: 25,),
              Icon(Icons.edit,size: 25,),
              Icon(Icons.add_circle_outline, size: 25,),
              Icon(Icons.keyboard_arrow_right,size: 25,),
              Icon(Icons.last_page,size: 25,),
            ],
            color:Colors.white,
            backgroundColor: Colors.blueGrey[50],
            animationCurve: Curves.easeOutCubic,
            animationDuration:Duration(milliseconds: 600),
            onTap:(index){
              setState(() {
//                _page=index;

                if(index ==0){
                  if(_page > 0){
                    _page=_page-1;
                  }
                }
//                if(index == 1){
//                  if(_page > 0){
//                    _page=_page-1;
//                  }
//                }
//                if(index == 2){
//                  _page = index;
//                }
//                if(index == 3){
//                  _page = index;
//                }
//                if(index == 4){
//                  _page = index;
//                }
//                if(index == 5){
//                  if(_page < EnglishVersion.length-1){
//                    _page=_page+1;
//                  }
//                }
                if(index == 6){
                 if(_page < EnglishVersion.length-1){
                    _page=_page+1;
                  }
                }
              });
            }
        ),
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(40.0), // here the desired height
            child: AppBar(
              backgroundColor: Colors.blue,
              title: Text("Edit Translation"),
            )
        ),
        body: Container(
          color: Colors.blueGrey[50],
          child: new Column(
            crossAxisAlignment:   CrossAxisAlignment.start,
            children: <Widget>[
              Text.rich(
                TextSpan(
                  children: <TextSpan>[
                    TextSpan(text: EnglishVersion[_page],style: TextStyle(fontSize: 17.0))],
                ),
              ),
//              ListTile(),
              Divider(color: Colors.black,height: 20.0,),
              Text.rich(
                TextSpan(
                  children: <TextSpan>[
                    TextSpan(text: GoogleVersion[_page]),
//                    TextSpan(text: "ఒక సంప్రదాయం అనేది ఒక సమూహం లేదా సమాజం లోపల ఒక నమ్మకం లేదా ఒక ప్రవర్తన ఒక సింబాలిక్ అర్థం లేదా గతంలో మూలాలు తో ప్రత్యేక ప్రాముఖ్యత తో ఆమోదించింది.",style: TextStyle(fontSize: 15.0,),),
                  ],
                ),
              ),
//              ListTile(),
              Divider(color: Colors.black,height: 20.0,),
              ListTile(
                title:
                TextField(),
//                trailing: Icon(Icons.delete),
              )
            ],
          ),
        )
    );
  }
}
package com.example.teluguwikitranslation;
import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.ActionBar;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import java.text.BreakIterator;
import java.util.Date;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.io.IOException;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import android.view.Menu;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Switch;
import android.view.Window;
import android.widget.CheckBox;
import android.text.method.ScrollingMovementMethod;
import android.util.EventLog;
import android.util.Log;
import android.view.KeyEvent;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.view.KeyEvent.Callback;
import java.io.FileInputStream;
import java.security.PublicKey;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    EditText  editPassword;
    TextView textView,editName;
    Button buttonSubmit;
    String temp = "";
    String FILE_NAME = "example.txt";
    Button button,button1,button4;
    public Switch switch1;
    public ClipboardManager clipboardManager;
    public ClipData clipData;
    final String microsoft = "Microsoft Translate: ";
    final String google="Google Translate: ";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        android.support.v7.app.ActionBar AB=getSupportActionBar();
        AB.hide();
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        editName = (TextView) findViewById(R.id.editName);editName.setText("Google Translate: "+"అవుల్ పకీర్ జైనుల్లాబ్దీన్ అబ్దుల్ కలాం (/ˈ æbdఈ l kə ˈ lɑ ː m/(ఈ సౌండ్ విష్ గురించి); 15 అక్టోబర్ 1931 – 27 జూలై 2015) భారతదేశ 11 వ రాష్ట్రపతిగా 2002 నుండి 2007 వరకు పనిచేసిన ఒక ఏరోస్పేస్ శాస్త్రవేత్త. ");
        textView = (TextView) findViewById(R.id.textView);
        switch1 = (Switch) findViewById(R.id.switch1);

        switch1.setChecked(false);
        switch1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!switch1.isChecked()){
                    editName.setText(google+"అవుల్ పకీర్ జైనుల్లాబ్దీన్ అబ్దుల్ కలాం (/ˈ æbdఈ l kə ˈ lɑ ː m/(ఈ సౌండ్ విష్ గురించి); 15 అక్టోబర్ 1931 – 27 జూలై 2015) భారతదేశ 11 వ రాష్ట్రపతిగా 2002 నుండి 2007 వరకు పనిచేసిన ఒక ఏరోస్పేస్ శాస్త్రవేత్త. ");
                }else{
                    editName.setText(microsoft+"అబ్దుల్ పాకిర్ జైనులబ్దేన్ అబ్దుల్ కలాం (ఈ సౌండ్ లిస్టు గురించి) (అక్టోబర్ 15, 1931 - 27 జులై, 2015) ఒక అంతరిక్ష శాస్త్రవేత్త. 2002 నుండి 2007 వరకు భారతదేశం యొక్క 11 వ రాష్ట్రపతిగా పనిచేశారు.");
                }
            }
        });
//        if(switch1.isChecked()){
//            editName.setText("Switch is currently ON");
//        }
//        else {
//            editName.setText("Switch is currently OFF");
//        }

        addListenerOnButton();
        addListenerOnButton1();

        clipboardManager = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            }
        }

        editPassword = (EditText) findViewById(R.id.editPassword);
//        result = (TextView) findViewById(R.id.tvResult);
//        buttonSubmit = (Button) findViewById(R.id.buttonSubmit);
        TextView editName = (TextView) findViewById(R.id.editName);
//        editName.setText("అట్లాస్ ష్రగ్డ్ అనేది అయన్ రాండ్ 1957 లో వచ్చిన నవల. రాండ్ యొక్క నాల్గవది మరియు ఆఖరి నవల, ఇది ఆమె పొడవైనది, మరియు ఆమె ఫిక్షన్ రచన రంగానికి సంబంధించి ఆమె గొప్ప ప్రదర్శనగా భావించేది");

        editPassword.addTextChangedListener(new TextWatcher() {
            public  void afterTextChanged(Editable s){
//                Toast.makeText(getApplicationContext(),"after text change :"+s, LENGTH_SHORT).show();
                temp += "Typed: "+s+" at: ";
//                Toast.makeText(getApplicationContext(),"temp data: "+temp,Toast.LENGTH_LONG).show();
            }
//
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//                Toast.makeText(getApplicationContext(),"before text"+s, LENGTH_SHORT).show();
                /*This method is called to notify you that, within s, the count characters beginning at start are about to be replaced by new text with length after. It is an error to attempt to make changes to s from this callback.*/
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                Toast.makeText(getApplicationContext(),"on text change "+s, LENGTH_SHORT).show();
            }
        });
//
    }



    private void addListenerOnButton1() {
        final Context context = this;

        button = (Button) findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, NextActivity.class);
                startActivity(intent);

            }

        });
    }

    public void addListenerOnButton() {

        final Context context = this;

        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, PrevActivity.class);
                startActivity(intent);

            }

        });
    }


    public void  save(View view)  // SAVE
    {

        Toast.makeText(this,"Saved Content",Toast.LENGTH_LONG).show();
        editName.setText("");
        textView.setText("");
        editPassword.setText("");

        final Context context = this;

        Button checkBox = (Button) findViewById(R.id.checkBox);
        checkBox.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, NextActivity.class);
                startActivity(intent);

            }

        });

        Button checkBox2 = (Button) findViewById(R.id.checkBox2);
        checkBox.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, NextActivity.class);
                startActivity(intent);

            }

        });



//        String password = editPassword.getText().toString();
//        result.setText(password);
//        editPassword.setText("Hello world!");
//        editName.setText("Hello world!");
//        textView.setText("Hello world!");
//        String text = "";
//        FileOutputStream fos = null;
//        try{
//            Date date = new Date();
//            DateFormat dateFormat= DateFormat.getTimeInstance(DateFormat.LONG);
//            String currentTime = dateFormat.format(date);
//            Toast.makeText(this,"temp data: "+temp,Toast.LENGTH_LONG).show();
//            text= temp+currentTime+"/n";
//
//            fos = openFileOutput(FILE_NAME,MODE_PRIVATE);
//            fos.write(text.getBytes());
//            Toast.makeText(this,"Saved to "+getFilesDir()+"/"+FILE_NAME,Toast.LENGTH_LONG).show();
//            temp = "";
//        }
//        catch (FileNotFoundException e){
//            e.printStackTrace();
//        }
//        catch (IOException e){
//            e.printStackTrace();
//        }
//        finally {
//            if(fos !=null){
//                try {
//                    fos.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
    }

    public void Edit(View view) {
        String txtCopy = editName.getText().toString();
        clipData = ClipData.newPlainText("text",txtCopy);
        clipboardManager.setPrimaryClip(clipData);
//        Toast.makeText(getApplicationContext(),"Data Copied to Clipboard", Toast.LENGTH_SHORT).show();
        ClipData pData = clipboardManager.getPrimaryClip();
        ClipData.Item item = pData.getItemAt(0);
        String txtpaste = item.getText().toString();
        if(txtpaste.charAt(0)=='G'){
            txtpaste = txtpaste.substring(google.length());
        }
        else if(txtpaste.charAt(0)=='M'){
            txtpaste = txtpaste.substring(microsoft.length());
        }
        editPassword.setText(txtpaste);
//        Toast.makeText(getApplicationContext(),"Data Pasted from Clipboard",Toast.LENGTH_SHORT).show();
    }
}

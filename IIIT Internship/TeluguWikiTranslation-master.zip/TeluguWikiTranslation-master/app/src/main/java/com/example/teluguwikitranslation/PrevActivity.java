package com.example.teluguwikitranslation;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class PrevActivity extends Activity {
    Button button;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prevfile);
    }

}

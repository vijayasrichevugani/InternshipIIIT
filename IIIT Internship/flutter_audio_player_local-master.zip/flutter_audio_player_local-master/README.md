# localaudioflutterapp

A flutter audioplayer example that runs on both iOS and android and provides play, pause, seek (using a slider) and stop functionality.

![Android](https://github.com/samupra/local_flutter_audio_player/blob/master/android_nexus_emu.png)

# Donate

Buy me a cup of coffee if this helped you! I will really appreciate it. 
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=F3JRJJKXZSBBL)